module.exports = {
    users: [
        {
            email: "admin@loops.com",
            password: "Malinga99",
        },
    ],
};